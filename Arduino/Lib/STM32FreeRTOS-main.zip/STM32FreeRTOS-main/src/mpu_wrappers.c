/*
 * @file    mpu_wrappers.c
 * @author  Frederic Pillon <frederic.pillon@st.com> for STMicroelectronics.
 * @brief   Include source file to match Arduino library format
 */

/* MPU not supported */
/*#include "../portable/Common/mpu_wrappers.c"*/
